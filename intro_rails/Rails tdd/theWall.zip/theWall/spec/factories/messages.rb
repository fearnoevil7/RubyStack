FactoryBot.define do
  factory :message do
    message { "Hello my name is jonathon" }
    user
  end
end
