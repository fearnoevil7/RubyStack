FactoryBot.define do
  factory :product do
    name { "MyString" }
    user { nil }
  end
end
