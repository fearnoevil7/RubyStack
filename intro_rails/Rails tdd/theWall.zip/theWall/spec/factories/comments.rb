FactoryBot.define do
  factory :comment do
    comment { "Hello Jonathon how's it going?" }
    message
    user
  end
end
