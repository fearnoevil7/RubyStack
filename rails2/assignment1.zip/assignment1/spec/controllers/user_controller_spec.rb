require 'rails_helper'

RSpec.describe UserController, type: :controller do

end
