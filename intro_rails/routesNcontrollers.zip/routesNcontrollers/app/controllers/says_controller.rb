class SaysController < ApplicationController
    def index
        render text: "What do you want me to say"
    end
end
