FactoryBot.define do
  factory :user do
    username { "fearnoevil7" }
  end
end
