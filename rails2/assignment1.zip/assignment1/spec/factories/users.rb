FactoryBot.define do
  factory :user do
    name { "Jonathon" }
    email { "jonsong94@yahoo.com" }
    password { "angelica16" }
  end
end
