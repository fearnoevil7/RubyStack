class Say < ApplicationRecord
end
