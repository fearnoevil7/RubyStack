module JoinsHelper
end
