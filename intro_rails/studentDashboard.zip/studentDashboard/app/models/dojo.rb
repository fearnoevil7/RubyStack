class Dojo < ApplicationRecord
    has_many :students
end
