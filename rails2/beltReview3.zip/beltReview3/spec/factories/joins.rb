FactoryBot.define do
  factory :join do
    user { nil }
    event { nil }
  end
end
